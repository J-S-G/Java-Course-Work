package com.mycompany.module6project1driver;

/**
 * Desc: Creates prioritized tasks. Ea. task tasks performs a unique task.
 * @author Joseph G.
 */
// Interface is similar to a class 
public interface PrioritizedTask
{
    static final int MED_PRIORITY = 5; 
    static final int MAX_PRIORITY = 10; 
    static final int MIN_PRIORITY = 1; 
    
    // Getter / Mutator 
    public int getPriority();
    
    public void setPriority(int Priority);
        
}

