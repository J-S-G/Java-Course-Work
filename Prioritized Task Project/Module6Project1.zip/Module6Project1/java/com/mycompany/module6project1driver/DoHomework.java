package com.mycompany.module6project1driver;

/**
 *
 * @author jg
 */
public class DoHomework extends Task
{

    // initialized constructor 
    public DoHomework() 
    {
        
    }
    
    // The executeTask method prints when chained with DoHomework 
    @Override
    public void executeTask() 
    {
        System.out.println("Doing homework");
    }
    
}
