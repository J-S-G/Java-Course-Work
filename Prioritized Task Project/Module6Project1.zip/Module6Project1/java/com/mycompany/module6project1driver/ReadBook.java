package com.mycompany.module6project1driver;

/**
 *
 * @author jg
 */
public class ReadBook extends Task
{
    // initialized constructor 
    public ReadBook()
    {
        
    }
    public void executeTask()
    {
        System.out.println("Reading book");
    }
    
    // Method prints the output when chained with the ReadBook class
    // Depending on the class and method a certain output is printed 
    public void browseLibrary()
    {
        System.out.println("Browsing library");
    }
}
