package com.mycompany.module6project1driver;

/**
 *
 * @author jg
 */
public class MowLawn extends Task
{
    // initialized constructor 
    public MowLawn() 
    {
        
    }
    
    // Method prints the output when chained with the MowLawn class
    // Depending on the class and method a certain output is printed 
    @Override
    public void executeTask() 
    {
        System.out.println("Mowing lawn");
    }
}
