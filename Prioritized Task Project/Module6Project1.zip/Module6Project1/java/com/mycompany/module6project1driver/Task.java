package com.mycompany.module6project1driver;

/**
 *
 * @author Joseph G.
 */
public abstract class Task implements PrioritizedTask
{   
    int priority;
    
    // Constructor 
    public Task()
    {
        priority = MED_PRIORITY;
    }
    
    // Getter / Mutator 
    public int getPriority() 
    {
        return priority;
    }

    public void setPriority(int Priority) 
    {
        priority = Priority;
    }
    
    // The abstract executeTask method does not return anything
    abstract void executeTask();
    
}
